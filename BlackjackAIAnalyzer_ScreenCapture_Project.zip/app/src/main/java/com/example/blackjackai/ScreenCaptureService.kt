package com.example.blackjackai

import android.app.*
import android.content.Intent
import android.graphics.Bitmap
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotification()
        val code = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("data", Intent::class.java) else @Suppress("DEPRECATION") intent?.getParcelableExtra("data")
        if (code != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, handler)
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        reader = ImageReader.newInstance(width, height, android.graphics.PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay("BlackjackCapture", width, height, metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, handler)
        // Allow the user time to switch to the blackjack game before the one-shot capture.
        handler.postDelayed({ captureOnce() }, 7000)
        return START_NOT_STICKY
    }

    private fun createNotification() {
        val channelId = "screen_capture"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Screen capture", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Blackjack AI Analyzer")
            .setContentText("ဂိမ်းမျက်နှာပြင်ကို ဖတ်ရန် ပြင်ဆင်နေသည်")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        startForeground(41, notification)
    }

    private fun captureOnce() {
        val image = reader?.acquireLatestImage()
        if (image == null) { sendResult("မျက်နှာပြင်ဖတ်မရပါ။ ထပ်စမ်းပါ။"); return }
        try {
            val plane = image.planes[0]
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width
            val padded = Bitmap.createBitmap(image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888)
            padded.copyPixelsFromBuffer(plane.buffer)
            val bitmap = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
            padded.recycle()
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener { text -> sendResult(text.text) }
                .addOnFailureListener { sendResult("OCR အမှား: ${it.localizedMessage}") }
                .addOnCompleteListener { recognizer.close(); bitmap.recycle(); stopSelf() }
        } catch (e: Exception) { sendResult("ဖတ်မရပါ: ${e.localizedMessage}"); stopSelf() }
        finally { image.close() }
    }

    private fun sendResult(text: String) {
        sendBroadcast(Intent("${packageName}.SCREEN_OCR_RESULT").setPackage(packageName).putExtra("text", text))
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        display?.release(); reader?.close(); projection?.stop()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?) = null
}
